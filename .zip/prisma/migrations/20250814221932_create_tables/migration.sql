/*
  Warnings:

  - You are about to alter the column `unit_price` on the `product` table. The data in that column could be lost. The data in that column will be cast from `Decimal` to `Decimal(10,2)`.
  - You are about to alter the column `stock_quantity` on the `product` table. The data in that column could be lost. The data in that column will be cast from `Decimal` to `Decimal(10,2)`.
  - You are about to alter the column `quantity` on the `sale_order_item` table. The data in that column could be lost. The data in that column will be cast from `Decimal` to `Decimal(10,2)`.

*/
-- DropForeignKey
ALTER TABLE "review" DROP CONSTRAINT "fk_review_member";

-- DropForeignKey
ALTER TABLE "review" DROP CONSTRAINT "fk_review_product";

-- DropForeignKey
ALTER TABLE "sale_order" DROP CONSTRAINT "fk_sale_order_member";

-- DropForeignKey
ALTER TABLE "sale_order_item" DROP CONSTRAINT "fk_sale_order_item_product";

-- DropForeignKey
ALTER TABLE "sale_order_item" DROP CONSTRAINT "fk_sale_order_item_sale_order";

-- AlterTable
ALTER TABLE "product" ALTER COLUMN "unit_price" SET DATA TYPE DECIMAL(10,2),
ALTER COLUMN "stock_quantity" SET DATA TYPE DECIMAL(10,2);

-- AlterTable
ALTER TABLE "sale_order_item" ALTER COLUMN "quantity" SET DATA TYPE DECIMAL(10,2);

-- CreateTable
CREATE TABLE "cart" (
    "id" SERIAL NOT NULL,
    "member_id" INTEGER NOT NULL,
    "created_at" TIMESTAMP(6) DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "cart_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "cartItem" (
    "id" SERIAL NOT NULL,
    "cart_id" INTEGER NOT NULL,
    "product_id" INTEGER NOT NULL,
    "quantity" DECIMAL(10,2) NOT NULL,

    CONSTRAINT "cartItem_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "discount" (
    "id" SERIAL NOT NULL,
    "name" VARCHAR(255) NOT NULL,
    "description" TEXT,
    "discount_percentage" DECIMAL(5,2) NOT NULL,
    "start_at" TIMESTAMP(6) NOT NULL,
    "end_at" TIMESTAMP(6) NOT NULL,

    CONSTRAINT "discount_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "_product_discounts" (
    "A" INTEGER NOT NULL,
    "B" INTEGER NOT NULL
);

-- CreateIndex
CREATE UNIQUE INDEX "_product_discounts_AB_unique" ON "_product_discounts"("A", "B");

-- CreateIndex
CREATE INDEX "_product_discounts_B_index" ON "_product_discounts"("B");

-- RenameForeignKey
ALTER TABLE "comment" RENAME CONSTRAINT "fk_comment_member" TO "comment_member_id_fkey";

-- RenameForeignKey
ALTER TABLE "comment" RENAME CONSTRAINT "fk_comment_review" TO "comment_review_id_fkey";

-- RenameForeignKey
ALTER TABLE "member" RENAME CONSTRAINT "fk_member_role_id" TO "member_role_fkey";

-- AddForeignKey
ALTER TABLE "review" ADD CONSTRAINT "review_member_id_fkey" FOREIGN KEY ("member_id") REFERENCES "member"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "review" ADD CONSTRAINT "review_product_id_fkey" FOREIGN KEY ("product_id") REFERENCES "product"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "sale_order" ADD CONSTRAINT "sale_order_member_id_fkey" FOREIGN KEY ("member_id") REFERENCES "member"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "sale_order_item" ADD CONSTRAINT "sale_order_item_product_id_fkey" FOREIGN KEY ("product_id") REFERENCES "product"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "sale_order_item" ADD CONSTRAINT "sale_order_item_sale_order_id_fkey" FOREIGN KEY ("sale_order_id") REFERENCES "sale_order"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "cart" ADD CONSTRAINT "cart_member_id_fkey" FOREIGN KEY ("member_id") REFERENCES "member"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "cartItem" ADD CONSTRAINT "cartItem_cart_id_fkey" FOREIGN KEY ("cart_id") REFERENCES "cart"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "cartItem" ADD CONSTRAINT "cartItem_product_id_fkey" FOREIGN KEY ("product_id") REFERENCES "product"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_product_discounts" ADD CONSTRAINT "_product_discounts_A_fkey" FOREIGN KEY ("A") REFERENCES "discount"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_product_discounts" ADD CONSTRAINT "_product_discounts_B_fkey" FOREIGN KEY ("B") REFERENCES "product"("id") ON DELETE CASCADE ON UPDATE CASCADE;
