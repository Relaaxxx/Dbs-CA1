// you can modify the code below to suit your needs
const { EMPTY_RESULT_ERROR, UNIQUE_VIOLATION_ERROR } = require('../errors');
const cartsModel = require('../models/carts');

module.exports.createCartItems = function (req, res) {

}

module.exports.updateCartItems = function (req, res) {

}

module.exports.retrieveCartItems = function (req, res) {

}

module.exports.deleteCartItems = function (req, res) {

}

module.exports.getCartSummary = function (req, res) {

}